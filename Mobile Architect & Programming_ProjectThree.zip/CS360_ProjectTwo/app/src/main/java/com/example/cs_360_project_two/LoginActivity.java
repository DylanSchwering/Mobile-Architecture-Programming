package com.example.cs_360_project_two;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;


public class LoginActivity extends AppCompatActivity {
    private EditText etUsername, etPassword;
    private Button btnSignIn, btnSignUp;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login); // your XML

        // Bind views
        etUsername = findViewById(R.id.editTextText);
        etPassword = findViewById(R.id.editTextTextPassword);
        btnSignIn   = findViewById(R.id.button);
        btnSignUp   = findViewById(R.id.button2);

        db = new DatabaseHelper(this);

        btnSignIn.setOnClickListener(v -> attemptLogin());
        btnSignUp.setOnClickListener(v -> attemptSignUp());
    }

    private void attemptLogin() {
        String u = etUsername.getText().toString().trim();
        String p = etPassword.getText().toString();
        if (db.checkUserCredentials(u, p)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    private void attemptSignUp() {
        String u = etUsername.getText().toString().trim();
        String p = etPassword.getText().toString();
        if (db.registerUser(u, p)) {
            Toast.makeText(this, "Account created – please sign in", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Sign‑up failed", Toast.LENGTH_SHORT).show();
        }
    }
}

